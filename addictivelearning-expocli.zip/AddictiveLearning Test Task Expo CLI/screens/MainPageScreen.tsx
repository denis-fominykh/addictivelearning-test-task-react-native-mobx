import React, { FC } from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import HomePageScreen from './HomePageScreen';
import SettingsPageScreen from './SettingsPageScreen';

const Tab = createBottomTabNavigator();

const MainPageScreen: FC = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: string = '';

          if (route.name === 'Home') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'Settings') {
            iconName = focused ? 'settings' : 'settings-outline';
          }

          return (
            <MaterialCommunityIcons name={iconName} size={size} color={color} />
          );
        },
      })}
      tabBarOptions={{
        activeTintColor: '#DE0160',
        inactiveTintColor: 'gray',
      }}
    >
      <Tab.Screen name="Home" component={HomePageScreen} />
      <Tab.Screen name="Settings" component={SettingsPageScreen} />
    </Tab.Navigator>
  );
};

export default MainPageScreen;
